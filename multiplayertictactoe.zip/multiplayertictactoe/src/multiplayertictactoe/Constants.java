/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multiplayertictactoe;

/**
 * Defines the IP address, types of messages and other useful constants
 * @author daogamez
 */
public interface Constants {
    //NETWORK PARAMETERS
    //Name of the host
    final String hostName = "localhost";
        
    //Port number for the connection
    final int portNumber = 4444;
    
    
    //DEBUGGING
    //Set this to true if you want detailed debugging information to be output
    final boolean DEBUG = false;
    
    
    //MESSAGE TYPES
    //Player is ready to play
    final int READY_MSG = 1;
    
    //The player has drawn the game
    final int PLAYER_DRAW_MSG = 2;
    
    //The player has won the game
    final int PLAYER_WON_MSG = 3;
    
    //The player has lost the game
    final int PLAYER_LOST_MSG = 4;
    
    //The player has been allocated the X counter
    final int PLAYER_IS_X_MSG = 5;
    
    //The player has been allocated the O counter
    final int PLAYER_IS_O_MSG = 6;
    
    //Player adds X to the board
    final int ADD_X_MSG = 7;
    
    //Player adds O to the board
    final int ADD_O_MSG = 8;
    
    //The board has been updated
    final int BOARD_UPDATE_MSG = 9;
    
    
    //DEFINITIONS OF THE TYPES OF MARKS - USE THESE TO AVOID CARELESS MISTAKES AND AMBIGUITY
    //The mark used by the nought player
    final char NOUGHT = 'O';
    
    //The mark used by the cross player
    final char CROSS = 'X';
    
    //A blank cell on the board
    final char BLANK = ' ';   
}
