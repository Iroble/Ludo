/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multiplayertictactoe;

/**
 * Message that is used to play game. Different fields in the message are used depending on the message type.
 * @author daogamez
 */
public class Message implements java.io.Serializable {
    //Type of message - message types are defined in Constants
    private int messageType;
    
    //X position in the board
    private int xPos;
    
    //Y position in the board
    private int yPos;
    
    //The mark that is placed by a player on the board - defined in Constants
    private char mark;
    
    
    //Constructor
    Message(int type){
        this.messageType = type;
    }
    
    
    //Constructor
    Message(int type, int xPos, int yPos, char mark) throws Exception{
        this.messageType = type;
        if(xPos < 0 || xPos > 2)
            throw new Exception ("xPos out of range: " + xPos);
        this.xPos = xPos;
        if(yPos < 0 || yPos > 2)
            throw new Exception ("yPos out of range: " + yPos);
        this.yPos = yPos;
        if(mark == 'X' || mark == 'O')
            this.mark = mark;
        else
            throw new Exception("Mark not recognized: " + mark);
    }
    
  
    //------------------------------------------------------------------
    //------------------------ PUBLIC METHODS --------------------------
    //------------------------------------------------------------------
    
    //Returns the message type
    public int getType(){
        return messageType;
    }
    
    
    //Returns the x position
    public int getXPos(){
        return xPos;
    }
    
    
    //Returns the y position
    public int getYPos(){
        return yPos;
    }
    
    
    //Returns the mark (O or X)
    public char getMark(){
        return mark;
    }
    
    
    //String version of message
    public String toString(){
        return "Message type: " + messageType + "; xPos=" + xPos + "; yPos=" + yPos + "; mark='" + mark + "'";
    }
    
}
