/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multiplayertictactoe;

import java.util.Scanner;
import static multiplayertictactoe.Constants.DEBUG;

/**
 * Tic Tac  Toe server launches a ConnectionListener to handle games
 */
public class TicTacToeServer implements Constants {
    
    public static void main(String[] args){
        //Create a connection listener to listen and accept connections
        ConnectionListener listener = new ConnectionListener();
        listener.start();
                
        //Read input from user.
        System.out.println("Type 'stop' to shut down the server");
        Scanner scanner = new Scanner(System.in);
        String userInput = scanner.nextLine();
        while(!userInput.equals("stop")){
            userInput = scanner.nextLine();
        }
        
        //Stop thread when user types stop
        if(DEBUG) System.out.println("TicTacToeServer: Stopping listener");
        listener.stopThread();
        try{
            listener.join();
        }
        catch(InterruptedException ex){
            ex.printStackTrace();
        } 
        System.out.println("Exiting TicTacToeServer.");
    }
}
