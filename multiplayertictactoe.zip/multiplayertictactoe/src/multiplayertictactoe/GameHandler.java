/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multiplayertictactoe;

import java.io.*;
import java.net.*;
import static multiplayertictactoe.Constants.ADD_O_MSG;
import static multiplayertictactoe.Constants.ADD_X_MSG;
import static multiplayertictactoe.Constants.BOARD_UPDATE_MSG;
import static multiplayertictactoe.Constants.CROSS;
import static multiplayertictactoe.Constants.DEBUG;
import static multiplayertictactoe.Constants.NOUGHT;
import static multiplayertictactoe.Constants.PLAYER_DRAW_MSG;
import static multiplayertictactoe.Constants.PLAYER_IS_O_MSG;
import static multiplayertictactoe.Constants.PLAYER_IS_X_MSG;
import static multiplayertictactoe.Constants.PLAYER_LOST_MSG;
import static multiplayertictactoe.Constants.PLAYER_WON_MSG;
import static multiplayertictactoe.Constants.READY_MSG;

/**
 * Handles a single Tic Tac Toe game between the two clients
 * @author daogamez
 */
public class GameHandler extends Thread implements Constants {
    //Socket that is managed by this class
    Socket socket1 = null;
    
    //Socket that is managed by this class
    Socket socket2 = null;
    
    //Ouput stream of the client allocated to crosses
    ObjectOutputStream crossOutputStream;
    
    //Input stream of the client allocated to crosses
    ObjectInputStream crossInputStream;

    //Ouput stream of the client allocated to noughts
    ObjectOutputStream noughtOutputStream;
    
    //Input stream of the client allocated to noughts
    ObjectInputStream noughtInputStream;
    
    //Board 
    Board board;
    
    //Used to shut the thread down
    boolean stopThread = true;

    
    //Constructor
    GameHandler(){
        board = new Board();
    }
    
    
    //------------------------------------------------------------------
    //------------------------ PUBLIC METHODS --------------------------
    //------------------------------------------------------------------
    
    //Adds the first player to the game
    public void addSocket1(Socket socket) throws IOException{
        //Create  object input and output streams for socket 1
        crossOutputStream = new ObjectOutputStream(socket.getOutputStream());
        crossInputStream  = new ObjectInputStream(socket.getInputStream());
        
        //Store reference to socket so that we can shut it down
        socket1 = socket;
    }
    
    
    //Adds the second player to the game
    public void addSocket2(Socket socket) throws IOException{
        //Create  object input and output streams for socket 2
        noughtOutputStream = new ObjectOutputStream(socket.getOutputStream());
        noughtInputStream = new ObjectInputStream(socket.getInputStream());
        
        //Store reference to socket so that we can shut it down
        socket2 = socket;
    }
    
    
    //Returns true if the first socket has been added
    public boolean hasSocket1(){
        if(socket1 == null)
            return false;
        return true;
    }
    
    
    //Returns true if the second socket has been added
    public boolean hasSocket2(){
        if(socket2 == null)
            return false;
        return true;
    }
   
    
    //Inherited from Thread
    public void run(){
        Message msg;
        
        try{
            if(DEBUG) System.out.println("GameHandler running. Game starting up");
                       
            //Wait for ready message from clients
            if(DEBUG) System.out.println("Waiting for ready message from clients");
            msg = receiveMessage(crossInputStream, READY_MSG);
            msg = receiveMessage(noughtInputStream, READY_MSG);
            
            //Allocate mark to players
            crossOutputStream.writeObject(new Message(PLAYER_IS_X_MSG));
            noughtOutputStream.writeObject(new Message(PLAYER_IS_O_MSG));
            
            //Play game
            stopThread = false;
            while(!stopThread){
                //Receive message from X, who moves first
                msg = receiveMessage(crossInputStream, ADD_X_MSG);
                
                //Update board with message
                board.addX(msg.getXPos(), msg.getYPos());
                
                //Check to see if game has finished
                if(board.gameOver()){
                    finishGame();
                    break;
                }
                
                //Send message to O to update the state of the board
                sendMessage(noughtOutputStream, BOARD_UPDATE_MSG, msg.getXPos(), msg.getYPos(), CROSS);
                    
                //Receive message from Y
                msg = receiveMessage(noughtInputStream, ADD_O_MSG);
                
                //Update board with message
                board.addO(msg.getXPos(), msg.getYPos());
                
                if(board.gameOver()){
                    finishGame();
                    break;
                }
                
                //Send message to X to update the state of the board
                sendMessage(crossOutputStream, BOARD_UPDATE_MSG, msg.getXPos(), msg.getYPos(), NOUGHT);
            }
             
            //Close sockets
            if(DEBUG) System.out.println("Game over: Shutting down GameHandler.");
            socket1.close();
            socket2.close();
        }
        catch(IOException ex){
            ex.printStackTrace();
        }
        catch(ClassNotFoundException ex){
            ex.printStackTrace();
        }
        catch(Exception ex){
            ex.printStackTrace();
        }
        finally{
            if(DEBUG) System.out.println("Exiting GameHandler");
        }
    }
    
     
    //Used by the server to shut the GameHandler down 
    public void stopThread(){
        stopThread = true;
    }
    
        
    //------------------------------------------------------------------
    //----------------------- PRIVATE METHODS --------------------------
    //------------------------------------------------------------------
    
    //When game is over, need to notify the players about the result
    private void finishGame() throws IOException , Exception {
        if(board.isWinner()){
            char winnerMark = board.getWinner();
            if(winnerMark == CROSS){
                sendMessage(crossOutputStream, PLAYER_WON_MSG);
                sendMessage(noughtOutputStream, PLAYER_LOST_MSG);
            }
            else {
                sendMessage(crossOutputStream, PLAYER_LOST_MSG);
                sendMessage(noughtOutputStream, PLAYER_WON_MSG);
            }
            return;
        }
        else if (board.isDraw()){
            sendMessage(crossOutputStream, PLAYER_DRAW_MSG);
            sendMessage(noughtOutputStream, PLAYER_DRAW_MSG);
            return;
        }
        throw new Exception("Board status should be winner or draw!");
    }
    
    
    //Receives a message from the specifeid client input stream
    private Message receiveMessage(ObjectInputStream iStream, int msgType) throws Exception{
        Message msg = (Message)iStream.readObject();
        if(DEBUG) System.out.println("GameHandler: Message received: " + msg.toString());
        if(msg.getType() == msgType)
            return msg;
        throw new Exception ("Unexpected message from X " + msg.toString());
    }
    
    
    //Sends a message to the specified client output stream
    private void sendMessage(ObjectOutputStream oStream, int msgType) throws IOException{
        Message msg = new Message(msgType);
        oStream.writeObject(msg);
        if(DEBUG) System.out.println("GameHandler: Message sent: " + msg.toString());
    }
    
    //Sends a message to the specified client output stream
    private void sendMessage(ObjectOutputStream oStream, int msgType, int xPos, int yPos, char mark) throws IOException, Exception {
        Message msg = new Message(msgType, xPos, yPos, mark);
        oStream.writeObject(msg);
        if(DEBUG) System.out.println("GameHandler: Message sent: " + msg.toString());
    }
    

}