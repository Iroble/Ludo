/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multiplayertictactoe;

import java.net.*;
import java.io.*;
import java.util.ArrayList;
import static multiplayertictactoe.Constants.DEBUG;
import static multiplayertictactoe.Constants.hostName;
import static multiplayertictactoe.Constants.portNumber;

/**
 * Listens for connections on a socket.
 * Accepts two connections and passes them to the GameHandler, which plays the game
 */
public class ConnectionListener extends Thread implements Constants {  
    //Keep track of all of the connections
    ArrayList<GameHandler> gameHandlerList = new ArrayList();
    
    //Used to shut the thread down
    boolean runThread = false;
    
    
    //------------------------------------------------------------------
    //------------------------ PUBLIC METHODS --------------------------
    //------------------------------------------------------------------
    
    //Inherited from Thread
    public void run(){
        try{
            //Internet address of host
            InetAddress hostAddress = InetAddress.getByName(hostName);
        
            //Create the socket that will listen for connections
            ServerSocket serverSocket = new  ServerSocket(portNumber, 50, hostAddress);
            
            //Set a timeout on the socket so that we can cleanly shut it down
            serverSocket.setSoTimeout(1000);
            
            /* This loop will keep running until the server shuts down
                    It receives two connections and launches a handler to play the game */
            runThread = true;
            while(runThread){
                //Create a connection handler to receive messages on socket
                GameHandler handler = new GameHandler();
            
                //Accept connection from first client
                while(runThread && !handler.hasSocket1()){
                    //Wait for two client to to connect and accept connection when it does
                    if(DEBUG) System.out.println("Waiting to receive connection from client 1");
                    try{
                        //Accept first connection
                        Socket clientSocket1 = serverSocket.accept();//Accept the new connection - block otherwise
                        if(DEBUG) System.out.println("ConnectionListener: Client 1 connection received on " + hostAddress);

                        //Add socket to game handler
                        handler.addSocket1(clientSocket1);
                    }
                    catch(SocketTimeoutException ex){
                        ;//Do nothing, this is normal behaviour
                    }
                }
                
                //Accept connection from second client
                while(runThread && !handler.hasSocket2()){
                    if(DEBUG) System.out.println("Waiting to receive connection from client 2");
                    try{
                        //Accept second connection
                        Socket clientSocket2 = serverSocket.accept();//Accept the new connection - block otherwise
                        if(DEBUG) System.out.println("ConnectionListener: Client 2 connection received on " + hostAddress);

                        //Add socket to game handler
                        handler.addSocket2(clientSocket2);
                    }
                    catch(SocketTimeoutException ex){
                        ;//Do nothing, this is normal behaviour
                    }
                }
                
                if(runThread){ 
                    //Store reference to GameHandler, so we can shut it down correctly
                    gameHandlerList.add(handler);

                    //Start separate thread to handle connection
                    if(DEBUG) System.out.println("Starting GameHandler");
                    handler.start();
               }
            }
            
            //Thread is shutting down. Close socket that we are listening on.
            if(DEBUG) System.out.println("Closing down ConnectionListener");
            serverSocket.close();
            
            //Close down GameHandlers
            for(GameHandler gHandler : gameHandlerList){
                if(gHandler.isAlive()){
                    gHandler.stopThread();
                    gHandler.join();
                }
            }
        }
        catch(UnknownHostException ex){
            ex.printStackTrace();
        }
        catch(IOException ex){
            ex.printStackTrace();
        }        
        catch(InterruptedException ex){
            ex.printStackTrace();
        }
    }
    
    
    //Used to stoip the thread
    public void stopThread(){
        runThread = false;
    }
    
}
