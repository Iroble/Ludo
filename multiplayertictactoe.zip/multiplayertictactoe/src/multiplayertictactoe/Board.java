/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multiplayertictactoe;

/**
 *
 * @author nele
 */
public class Board implements Constants {
    //Represents the 3x3 board    
    private char [][] board = new char[3][3];
    
    //Records when game is complete
    boolean gameOver = false;
    
    //Set to true when one person has one - instead of a draw
    boolean isWinner = false;
    
    //The mark (O or X) of the winning player.
    char winnerMark = BLANK;
    
    
    //Constructor
    Board(){
        //Initialize the board with empty cells
        for(int i=0; i<3; ++i){
            for(int j=0; j<3; ++j){
                board[i][j] = ' ';
            }
        }
    }
      
    
    //------------------------------------------------------------------
    //------------------------ PUBLIC METHODS --------------------------
    //------------------------------------------------------------------
    
    //Adds a cross to the board (with appropriate checks)
    public void addO(int xPos, int yPos) throws Exception {
        //Check position is not out of range
        if(xPos <0 || xPos > 2 || yPos < 0 || yPos > 2)
            throw new Exception ("Invalid board position: " + xPos + " " + yPos);
        
        //Check that specified location is empty
        if(board[xPos][yPos] != BLANK)
            throw new Exception ("Board position already occupied: " + xPos + " " + yPos);
        
        //Update board and check if game is over
        board[xPos][yPos] = NOUGHT;
        updateGameStatus();
    }
    
    
    //Adds a nought to the board (with appropriate checks)
    public void addX(int xPos, int yPos) throws Exception {
        //Check position is not out of range
        if(xPos <0 || xPos > 2 || yPos < 0 || yPos > 2)
            throw new Exception ("Invalid board position: " + xPos + " " + yPos);
        
        //Check that position is empty
        if(board[xPos][yPos] != BLANK)
            throw new Exception ("Board position already occupied: " + xPos + " " + yPos);
        
        //Update board and check if game is over
        board[xPos][yPos] = CROSS;
        updateGameStatus();
    }
    
    
    //Displays the board on the command line
    public void print(){
        System.out.println("[] 0|1|2");
        for(int i=0; i<3; ++i){
            System.out.println(i + "] " + board[0][i] + "|" + board[1][i] + "|" + board[2][i]);
        }
    }
    

    //Returns true if the game has finished
    public boolean gameOver(){
        return gameOver;
    }
    
    
    //Returns the mark (O or X) of the winning player
    public char getWinner() throws Exception {
        if(isWinner)
            return winnerMark;
        
        //No winner found - this method should only be called when there is a winner
        throw new Exception ("getWinner() should only be called when game is over.");
    }
    
    
    //Returns true if there has been a draw
    public boolean isDraw(){
        if(gameOver && !isWinner)
            return true;
        return false;
    }
    
    
    //Returns true if a player has won the game (instead of a draw)
    public boolean isWinner(){
        return isWinner;
    }

    
    //Returns the mark at the specified position in the board
    public char getMark(int xPos, int yPos) throws Exception {
        //Check it is not out of range
        if(xPos <0 || xPos > 2 || yPos < 0 || yPos > 2)
            throw new Exception ("Invalid board position: " + xPos + " " + yPos);
        return board[xPos][yPos];
    }
    
    
    //Returns true if all of the places in the board are occupied
    private boolean boardFull(){
        for(int i=0; i<3; ++i){
            for(int j=0; j<3; ++j){
                if(board[i][j] == BLANK)
                    return false;
            }
        }
        return true;
    }
    
    
    //------------------------------------------------------------------
    //----------------------- PRIVATE METHODS --------------------------
    //------------------------------------------------------------------
    
    //Looks for three matching tokens to determine if the game is won
    private boolean check3MatchingTokens(char token){
        //Check rows and columns for 3 matching symbols
        for(int i=0; i<3; ++i){
            //Check rows
            if(board[i][0] == token && board[i][1] == token && board[i][2] == token)
                return true;
            //Check columns
            if(board[0][i] == token && board[1][i] == token && board[2][i] == token)
                return true;
        }
        
        //Check diagonals
        if(board[0][0] == token && board[1][1] == token && board[2][2] == token)
            return true;
        if(board[0][2] == token && board[1][1] == token && board[2][0] == token)
            return true;
        
        //No winnder found
        return false;
    }

    
    //Runs checks to determine if the game has been won or drawn
    private void updateGameStatus(){
        if(check3MatchingTokens(CROSS)){
            gameOver = true;
            isWinner = true;
            winnerMark = CROSS;
        }
        else if(check3MatchingTokens(NOUGHT)){
            gameOver = true;
            isWinner = true;
            winnerMark = NOUGHT;
        }
        else if(boardFull()){
            gameOver = true;
            isWinner = false;
        }
    }
}
