/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multiplayertictactoe;import java.util.Scanner;

import java.io.*;
import java.net.*;
import java.util.Scanner;
import static multiplayertictactoe.Constants.ADD_O_MSG;
import static multiplayertictactoe.Constants.ADD_X_MSG;
import static multiplayertictactoe.Constants.BLANK;
import static multiplayertictactoe.Constants.BOARD_UPDATE_MSG;
import static multiplayertictactoe.Constants.CROSS;
import static multiplayertictactoe.Constants.DEBUG;
import static multiplayertictactoe.Constants.NOUGHT;
import static multiplayertictactoe.Constants.PLAYER_DRAW_MSG;
import static multiplayertictactoe.Constants.PLAYER_IS_O_MSG;
import static multiplayertictactoe.Constants.PLAYER_IS_X_MSG;
import static multiplayertictactoe.Constants.PLAYER_LOST_MSG;
import static multiplayertictactoe.Constants.PLAYER_WON_MSG;
import static multiplayertictactoe.Constants.READY_MSG;
import static multiplayertictactoe.Constants.hostName;
import static multiplayertictactoe.Constants.portNumber;

/**
 * Console-based Client for Tic Tac Toe game. 
 * @author daogamez
 */
public class TicTacToeClient extends Thread implements Constants {
    //Local copy of board
    Board board;
    
    //Records whether player is noughts or crosses
    boolean playerX;
    
    //Socket for communication with server
    Socket socket;
    
    //Output stream to write messages to server
    ObjectOutputStream ooStream;
    
     //Object input stream to receive message from the client's socket
    ObjectInputStream oiStream;

    //Scanner to read input from user
    Scanner userInput;

    
    //Constructor
    TicTacToeClient(){
    }

    
    //------------------------------------------------------------------
    //------------------------ PUBLIC METHODS --------------------------
    //------------------------------------------------------------------
    
    //Main method - constructs client and starts thread
    public static void main(String [] args){
        TicTacToeClient client = new TicTacToeClient();
        client.start();
    }
    
    
    //Inherited from Thread
    public void run(){
        try{
            //Scanner to read input from user
            userInput = new Scanner(System.in);

            //While loop that displays menu and responds to user commands
            while(!isInterrupted()){
                printMenu();
                String inputStr = userInput.nextLine();
                if(inputStr.equals("1"))
                    playGame();
                else if(inputStr.equals("2"))
                    this.interrupt();
            }
        }
        //Handle exceptions
        catch(UnknownHostException ex){
            System.err.println("Unknown host: " + hostName);
        }
        catch (IOException ex){
            System.err.println("Could not get io for connection to: " + hostName);
        }
        catch(Exception ex){
            System.err.println(ex.getMessage());
            ex.printStackTrace();
        }
    }
  
            
    //------------------------------------------------------------------
    //----------------------- PRIVATE METHODS --------------------------
    //------------------------------------------------------------------
       
    //Checks if the specified board position is in range and not occupied
    boolean boardPositionOk(int xPos, int yPos)throws Exception {
        if(xPos <0 || xPos > 2 || yPos < 0 || yPos >2)
            return false;
        if(board.getMark(xPos, yPos) != BLANK)
            return false;
        return true;
    }
    
    
    //Opens connection to server
    void connectToServer() throws IOException{
            //Internet address of host
            InetAddress hostAddress = InetAddress.getByName(hostName);
            
            //Create a socket that will connect to the host and port
            socket = new  Socket(hostAddress, portNumber);
            
            //Create an object output stream to write message
            ooStream = new ObjectOutputStream(socket.getOutputStream());

            //Create an object input stream to read messages
            oiStream = new ObjectInputStream(socket.getInputStream());
            
            if(DEBUG) System.out.println("TicTacToeClient: Successfully connected to server.");
    }

    
    //This method plays an actual game of Tic Tac Toe - reading input
    //sending messages to server, updating board etc.
    private void playGame() throws IOException, UnknownHostException, ClassNotFoundException, Exception{
        //Message we will receive
        Message msg;
        
        //Create a new connection to the server
        connectToServer();
        
        //Create a new board
        board = new Board();
        
        //Tell server we are ready
        sendMessage(READY_MSG);
        System.out.println("Waiting to play game");

        //Play the game
        boolean playingGame = true;
        while(playingGame){
            //Get message from server
            if(DEBUG) System.out.println("Waiting to receive message");
            msg = receiveMessage();
            
            switch(msg.getType()){
                case PLAYER_IS_X_MSG:
                    playerX = true;
                    System.out.println("You are X, you go first.");
                    readPlayerMove();
                    break;
                case PLAYER_IS_O_MSG:
                    playerX = false;
                    System.out.println("You are O, you need to wait for X.");
                    break;
                case BOARD_UPDATE_MSG:
                    if(msg.getMark() == CROSS)
                        board.addX(msg.getXPos(), msg.getYPos());
                    else if(msg.getMark() == NOUGHT)
                        board.addO(msg.getXPos(), msg.getYPos());
                    readPlayerMove();
                    break;
                case PLAYER_WON_MSG:
                    System.out.println("You have won.");
                    playingGame = false;
                    break;
                case PLAYER_LOST_MSG:
                    System.out.println("You have lost.");
                    playingGame = false;
                    break;
                case PLAYER_DRAW_MSG:
                    System.out.println("You have drawn.");
                    playingGame = false;
                    break;
                default:
                    throw new Exception("Message not recognized.");
            }
        }
        
        //Close socket
        if(DEBUG) System.out.println("Shutting down TicTacToeClient");
        socket.close();
    }
    
    
    //Prints out the top level menu
    private void printMenu(){
        System.out.println("1. Play Tic Tac Toe.");
        System.out.println("2. Exit.");
        System.out.println("Enter your choice");
    }
    
    
    //Reads a move from the player and sends the result to the server
    private void readPlayerMove() throws Exception, IOException{
        boolean posEntered = false;
        while(!posEntered){
            //Print out the board for the player to see
            board.print();
            
            //Read move from player
            System.out.println("Enter the place of your next mark.");
            String inputStr = userInput.nextLine();

            //Check input - it should consist of two numbers separated with a space
            String[] coordArr = inputStr.split(" ");
            int xPos = Integer.parseInt(coordArr[0]);
            int yPos = Integer.parseInt(coordArr[1]);
            
            //xPos and yPos are in valid bounds
            if(boardPositionOk(xPos, yPos)){
                posEntered = true;

                //Send new position to server
                if(playerX){
                    board.addX(xPos, yPos);
                    ooStream.writeObject(new Message(ADD_X_MSG, xPos, yPos, CROSS));
                }
                else{
                    board.addO(xPos, yPos);
                    ooStream.writeObject(new Message(ADD_O_MSG, xPos, yPos, NOUGHT));
                }
            }
            //Player has not entered a correct input
            else
                System.out.println("Input was not recognized - please try again");
        }
    }
    
    
    //Receives a message from the server
    private Message receiveMessage() throws IOException, ClassNotFoundException{
        Object object = oiStream.readObject();
            
        //Interpret object as a message
        Message msg = (Message)object;
        
        //Debug output
        if(DEBUG) System.out.println("TicTacToeClient: Message received: " + msg.toString());
        return msg;
    }
    
    
    //Sends the specified message to the server
    private void sendMessage(int msgType) throws IOException {
        Message msg = new Message(msgType);
        
        //Write message to stream and output debug if necessary
        ooStream.writeObject(msg);
        if(DEBUG) System.out.println("TicTacToeClient: Message sent: " + msg.toString());
    }

}



